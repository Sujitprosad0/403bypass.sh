# mroddit-403bypass.sh 🚫➡️✅

A powerful Bash-based tool for bypassing HTTP 403 Forbidden responses using multiple headers and path obfuscations. Created by [@mroddit](https://bugcrowd.com/mroddit) 🔥

## 🧪 Features

- ✅ 12+ header techniques (X-Forwarded, X-Host, etc.)
- ✅ Multiple path bypass methods (`%2e/`, `..;/`, etc.)
- ✅ Color-coded output
- ✅ Batch mode from URL list file
- ✅ Auto save successful attempts to `results.txt`

## ⚙️ Usage

### 🔹 Single URL:
```bash
./mroddit-403bypass.sh https://example.com/secret
```

### 🔹 Multiple URLs from file:
```bash
./mroddit-403bypass.sh -f urls.txt
```

## 📁 Output

Successful 200 responses are saved in `results.txt` with full path and header info.

## 🛡️ Disclaimer

This tool is for educational and authorized testing only. Use responsibly.

---

## ✨ Author

Built by **[@mroddit](https://bugcrowd.com/mroddit)** – Ethical hacker & bug bounty hunter.
